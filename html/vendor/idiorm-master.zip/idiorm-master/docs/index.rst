.. Idiorm documentation master file, created by
   sphinx-quickstart on Wed Nov 28 15:39:16 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Idiorm's documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 2

   philosophy
   installation
   configuration
   querying
   models
   transactions
   connections


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

