<?php

namespace Gaufrette\Functional\Adapter;

use Gaufrette\Adapter\Ftp;

class FtpTest extends FunctionalTestCase
{
}
