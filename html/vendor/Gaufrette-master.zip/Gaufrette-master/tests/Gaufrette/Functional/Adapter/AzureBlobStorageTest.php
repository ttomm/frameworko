<?php

namespace Gaufrette\Functional\Adapter;

class AzureBlobStorageTest extends FunctionalTestCase
{
}