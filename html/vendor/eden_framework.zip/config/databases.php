<?php //-->
return array (
	/*'default' => array(
		'host' 	=> '127.0.0.1',
		'name' 	=> '',
		'user' 	=> '',
		'pass' 	=> '',
		'type' 	=> 'mysql',
		'default' => true)*/);