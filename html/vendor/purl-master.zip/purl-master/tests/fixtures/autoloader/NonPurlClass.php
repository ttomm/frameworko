<?php

class NonPurlClass
{
    // A class not within the \Purl namespace
}