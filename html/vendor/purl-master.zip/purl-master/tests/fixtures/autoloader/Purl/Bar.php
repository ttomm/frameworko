<?php

namespace Purl;

class Bar
{
    // Purl\Bar
}