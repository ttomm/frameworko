<?php

namespace Purl;

class Foo
{
    // Purl\Foo
}