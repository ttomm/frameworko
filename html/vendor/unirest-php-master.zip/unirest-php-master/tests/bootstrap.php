<?php

require_once __DIR__ . '/../src/Unirest.php';

define('UPLOAD_FIXTURE', __DIR__ . '/fixtures/upload.txt');
